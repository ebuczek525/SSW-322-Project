'use strict'

const testModel = require('../models/testModel')
const express = require('express')

module.exports = db => {
    const router = express.Router()
  
    const wrapAsync = handler => (req, res) => handler(req)
      .then(result => res.json(result))
      .catch(error => res.status(500).json({ error: error.message }))
  
    router.get('/', wrapAsync(async function(req) {
      return db.collection('Tests').find().toArray()
    }))
  
    router.post('/', wrapAsync(async function(req) {
      const test = new testModel(req.body)
      await db.collection('Book').insertOne(book)
      return { test }
    }))
  
    return router
  }